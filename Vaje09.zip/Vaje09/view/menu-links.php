<p>[
<a href="<?= BASE_URL . "book" ?>">All books</a> |
<a href="<?= BASE_URL . "book/search" ?>">Search</a> |
<a href="<?= BASE_URL . "book/add" ?>">Add new</a> |
<a href="<?= BASE_URL . "user/login" ?>">Log-in</a> |
<a href="<?= BASE_URL . "../other/index.php" ?>"><code>PHP_SELF</code></a>
]</p>
