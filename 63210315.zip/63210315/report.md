# Poročilo

Aplikacija je enostavna bančna aplikacija, ki podpira le registrirane uporabnike. Uporabnikom dovoljuje hranjenje denarja na mobilni banki, ter njegovega prenašanja med uporabniki aplikacije.

Aplikacija hrani osnovne podatke o uporabnikih, njihova imena, priimke, mail, hash-irana gesla in kraj bivanja.

Uporabniki so vsakdanji ljudje, ki si želijo enostavnega bančništva. V aplikacijo se registrirajo, nato nujno v svoj profil vpišejo potrebne podatke pod my-profile in lahko začnejo z delovanjem.