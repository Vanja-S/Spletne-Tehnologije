# Uporabniki

V sistemu sta dva uporabnika, katerima je potrebno določiti še podatke, kot so naslov bivanja in telefonska, kar lahko naredimo, ko se prijavimo v sistem -> my-profile, samo tako dobita dostop do uporabe aplikacije.

Uporabnika sta:

joze.oblak@gmail.com
Rozica134!

jure.smole@gmail.com
Planica2023!